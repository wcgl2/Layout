#!/bin/bash

# For this script work correctly, DUT must have WiFi on and allow adb root. It'd be better if it also has WiFi verbose logging enabled.

DEFAULT_NAME="throughput_test_download"
DEFAULT_LAPTOP_IFACE="wlan0"
DEFAULT_TEST_LENGTH="120"
DEFAULT_WINDOW_TCP="2M"
DEFAULT_DUT_IFACE="wlan0"
DEFAULT_ITERATION=5

adb shell sudo killall iperf
source ./config.cfg
sleep 4s

if [ $? -neq 0 ]; then
  echo "Default values were selected." 
  
else
  echo "Parameters loaded from config file."
  TEST_NAME="${TEST_NAME:-${DEFAULT_NAME}}"
  LAPTOP_IFACE="${LAPTOP_IFACE:-${DEFAULT_LAPTOP_IFACE}}"
  TEST_LENGTH="${TEST_LENGTH:-${DEFAULT_TEST_LENGTH}}"
  WINDOW_TCP="${WINDOW_TCP:-${DEFAULT_WINDOW_TCP}}"
  DUT_IFACE="${DUT_IFACE:-${DEFAULT_DUT_IFACE}}"
  ITERATION=${ITERATION:-${DEFAULT_ITERATION}}
fi

# Basic functions
initializeTest(){
   adb root 
 }

endTest(){
  echo ""
  echo ""
  echo ""
  echo "Restarting the test..."
  sleep 6
  
 
}

# Any subsequent(*) commands which fail will cause the shell script to exit immediately
set -e

echo "Starting throughput test download."
echo ""
echo "Using $TEST_NAME as the test name and $LAPTOP_IFACE as the laptop interface."

mkdir $TEST_NAME
cd $TEST_NAME

ifconfig 

# Execute the test case.  
# Iperf (client -> server by default)

echo "Firstly, let's test TCP using Iperf:"
# DUT as server (Download)
for((i=1;i<=ITERATION;i++)); do 
mkdir tcp_download_"$i"
cd tcp_download_"$i"
initializeTest
adb shell data/data/com.nextdoordeveloper.miperf.miperf/files/iperf -s -i 1 &
iperf -c $DUT_IP -t $TEST_LENGTH -w $WINDOW_TCP -P4 -i 1 2>&1 | tee iperf_tcp_download.txt
endTest
cd ..
done
echo ""
