#!/bin/bash
sleep 5s
source ./setupDevices
setupDevices

