#!/bin/bash

#Interface
#First screen system
firstScreen=$(zenity --question \
	--title='KPI Automation' \
	--text='What do you need?' \
	--ok-label='Login' \
	--cancel-label='New User'
)

#If user select Login option
if [[ $? = 0 ]]; then
newUser=$(zenity --forms \
	--title='KPI Automation' \
	--text='Create your user' \
	--add-entry='Name:' \
	--add-password='Password' \
	--separator=',' \
	--ok-label='Login'
)

name=$(cut -d ',' -f 1 <<< "$newUser")
password=$(cut -d ',' -f 2 <<< "$newUser")

#Forms empty
if [[ -z "$name" ]]; then
zenity --error --text="Enter a name."
fi

if [[ -z "$password" ]]; then
zenity --error --text="Enter a password."
fi

zenity --info --text="Hello, $name"
 
else

#If user select Create login
newUser=$(zenity --forms \
	--title='KPI Automation' \
	--text='Create your user' \
	--add-entry='Name:' \
	--add-password='Password' \
	--separator=',' \
	--ok-label='Create'	

)
name=$(cut -d ',' -f 1 <<< "$newUser")
password=$(cut -d ',' -f 2 <<< "$newUser")

zenity --info --text="Hello, $name" 


#Forms empty
if [[ -z "$name" ]]; then
zenity --error --text="Enter a name."
fi

if [[ -z "$password" ]]; then
zenity --error --text="Enter a password."
fi

fi

Starttests=$(zenity --question \
	--title='KPI Automation' \
	--text='Menu' \
	--ok-label='Test Start' \
	--cancel-label='Test Register'
)

#Starting Device Setup
if [[ $? = 0 ]]; then
cd SetupDevice
(source ./setup.sh) | zenity --title "SETTING DEVICE" --progress --pulsate --auto-close --auto-kill
else
zenity --forms --title "KPI Automation" --text "Test Register" --add-entry "Type Test:" --add-entry "Target:" --ok-label='Create'
if [[ $? = 0 ]]; then
zenity --info --title "KPI Automation" --text "SAVED TEST!!"
fi
fi



#Starting tests STA Download e Upload
cd ..
cd STAexecution
zenity --info --title "KPI Automation" --text "Starting STA Tests..."
if [[ $? = 0 ]]; then
sleep 4s
source ./STAexecution
fi


